/*
  WARNING: Do not change impcore.h unless you intend to release new versions of everything that uses it. Your changes
           may not be used by the final application!
*/
#ifndef IMPCORE__
#define IMPCORE__
/******************************************************************************
*
* Copyright  2015 Imorphics, All Rights Reserved
*
* FILENAME: impcore.h
*
* DESCRIPTION: Contains the functions of the IMPCORE software.
*              All the types and functions used in this file have to be
*              compilable as "C" code, and the functions have to be defined
*              with extern "C" linkage, according to the ABI for the
*              given platform. This file contains the main description of the API.
*
*              This header will be shared outside Imorphics to define
*              the interface (API) to the Imorphics IMPCORE library.
*
******************************************************************************/


/*
Define the appropriate calling convention depending on compiler (e.g. MSVC or gcc) and
and whether this code is being used to build the IMP* library as DLL/DSO ("export")
or to link a built IMP* DLL/DSO with a client application ("import").
The macro IMPCORE_EXPORT will be defined at compile-time when building IMP* DLL/DSO.
It must be left undefined when linking a built IMP DLL/DSO with a client application.

For Visual Studio, use the Microsoft x64 calling convention (not __vectorcall).
For gcc, use the System V AMD64 ABI calling convention.
Both these calling conventions are the default on their respective platforms,
so at present they do not need to be explicitly declared.
However, this macro can be used to differentiate between multiple calling conventions
in future if required.

When compiling the DLL under Windows/Visual Studio, all items are hidden by default,
except those explicitly exported by a definitions (.def) file.
To produce the same behaviour under Linux/gcc, the IMP* library will be compiled with
-fvisibility=hidden, and those items in the API which are to be exported will be marked
with visibility attribute "default" i.e. visible.
*/
#ifdef _MSC_VER  /* This must be previously defined to indicate that we are using a Microsoft Visual Studio compiler */
#  ifdef IMPCORE_EXPORT  /* Building/exporting DLL */
#    define IMPCORE_API_CALL   __declspec(dllexport)
#  else  /* Using/importing DLL */
#    define IMPCORE_API_CALL   __declspec(dllimport)
#  endif
#elif __GNUC__ >= 4
#  ifdef IMPCORE_EXPORT  /* Building/exporting DSO */
#    define IMPCORE_API_CALL __attribute__ ((visibility ("default")))
#  else  /* Using/importing DSO */
#    define IMPCORE_API_CALL __attribute__ ((visibility ("default")))
#  endif
#else
#  error Require gcc v.4 or later
#endif

#ifndef __cplusplus
#  include <stdbool.h>
#endif
  
#ifdef __cplusplus
extern "C" {
#endif


/************************************************
*  Enumerations
************************************************/

/*! \brief Function return values.

All return values are hard-coded here. This allows us to deprecate some codes if required in the future.
This list is shared across all imp libraries and includes the return values for all imp functions.
If you change this list, ensure you update impcore_convert_rv_to_string() and impcore_convert_rv_from_string().
*/
enum impcore_rv 
{
  impcore_rv_success=0,                        /*!< Successful completion */
  impcore_rv_unknown_error=1,                  /*!< An unidentified error */
  impcore_rv_invalid_input=2,                  /*!< Input data failed validation test. */
  impcore_rv_invalid_patient_side=3,           /*!< The specified patient side was different from that expected. */
  impcore_rv_io_failure=4,                     /*!< An error occurred when trying to read or write a file or directory. */
  impcore_rv_incorrect_model_type=5,           /*!< The incorrect type of model was specified. */
  impcore_rv_statistical_algorithm_failure=6,  /*!< A statistical algorithm (any module) failed due to unusual data. */
  impcore_rv_cancelled=7,                      /*!< The operation was cancelled before completion. */
  impcore_rv_not_implemented=8,                /*!< Requested operation was not implemented / not part of given model. */
  impcore_rv_logging_config_failure=9,         /*!< Could not configure logging. */
  impcore_rv_postcondition_check_failure=10,   /*!< The results failed a postcondition check. */
  /* The next value must remain the final entry */
  impcore_rv_endstop                           /*!< This is not a meaningful return code, just one past the largest valid error. */
};

/*! \brief Anatomical side.

This list is shared across all imp libraries.
If you change this list, ensure you update impcore_convert_side_to_string() and impcore_convert_side_from_string().
*/
enum impcore_side_t
{
  impcore_side_undefined,  /*!< Patient side has not been specified, or is not meaningful, or is not important. */
  impcore_side_left,       /*!< Anatomy is on the patient's left side. */
  impcore_side_right,      /*!< Anatomy is on the patient's right side. */
  impcore_side_bilateral   /*!< Anatomy includes both left and right sides, e.g. both hips. */
};

/*! \brief Whether a model is GPU enabled */

enum impcore_gpu_enabled_t
{
    impcore_gpu_enabled_undefined,  /*!< Whether the model uses GPU is undefined */
    impcore_gpu_enabled_true,       /*!< The model uses GPU */
    impcore_gpu_enabled_false       /*!< The model does not use GPU */
};

/*! \brief What hardware the user has */

enum impcore_user_hardware_t
{
    impcore_user_hardware_undefined,  /*!< Whether the hardware is undefined */
    impcore_user_hardware_cpu,        /*!< No compute capability 6.1+ GPU was found. */
    impcore_user_hardware_gpu_6_1     /*!< When the hardware has GPU with cuda 6.1 or higher capabilities */
};
/************************************************
*  Public data types
************************************************/

/*! \brief A 3D point. */
struct impcore_point_t
{
  double x;
  double y;
  double z;
};

/*! \brief A set of 3D points. */
struct impcore_pointset_t
{
  unsigned int             n_points;  /*!< Size of points array. */
  struct impcore_point_t * points;    /*!< Pointer to start of points array. */
};

/*! \brief A triangle defined as 3 indices into an array of points. */
struct impcore_triangle_t
{
  unsigned int vertex1;
  unsigned int vertex2;
  unsigned int vertex3;
};

/*! \brief A set of triangles, each defined as 3 indices into the same array of points. */
struct impcore_triangleset_t
{
  unsigned int                n_triangles;  /*!< Size of triangles array. */
  struct impcore_triangle_t * triangles;    /*!< Pointer to start of triangles array. */
};

/*! \brief A set of indices (typically point indices into a surface mesh). */
struct impcore_indexset_t
{
  unsigned int   n_indices;  /*!< Size of index array. */
  unsigned int * indices;    /*!< Pointer to start of index array. */
};

/*! \brief A triangulated surface mesh. */
struct impcore_mesh_t
{
  const char *                 name;      /*!< Null-terminated string indicating part name. */
  struct impcore_pointset_t    vertices;  /*!< Vertices */
  struct impcore_triangleset_t faces;     /*!< Faces */
};

/*! \brief A set of meshes. */
struct impcore_meshset_t
{
  unsigned int            n_meshes; /*!< Size of meshes array. */
  struct impcore_mesh_t * meshes;   /*!< Pointer to start of meshes array. */
};

/*! \brief A contour made up of connected vertices. */
struct impcore_contour_t
{
  const char *                 name;      /*!< Null-terminated string indicating part name. */
  struct impcore_pointset_t    vertices;  /*!< Vertices */
  bool                         closed;    /*!< Whether contour is considered closed. */
};

/*! \brief Set of contours. */
struct impcore_contourset_t
{
  unsigned int               n_contours; /*!< Size of contours array. */
  struct impcore_contour_t * contours;   /*!< Pointer to start of contours array. */
};

/*! \brief Axis-aligned bounding box described by opposing corners. */
struct impcore_bounding_box_t
{
  struct impcore_point_t min;
  struct impcore_point_t max;
};

/*! \brief A statistic map, i.e. a statistical value (e.g. mean, sd, etc) computed at every vertex of a surface. */
struct impcore_statmap_t
{
  const char *  name;      /*!< Null-terminated string identifying the statistical value in this statmap. */
  unsigned int  n_values;  /*!< Number of statistical values. */
  double *      values;    /*!< Pointer to start of array of statistical values. */
};

/*! \brief A set of statistic maps, each a different statistic (e.g. mean, sd, etc) computed on the same surface (e.g. bone part). */
struct impcore_statmapset_t
{
  unsigned int               n_statmaps; /*!< Number of statmap pointers. */
  struct impcore_statmap_t * statmaps;   /*!< Pointer to start of array of statmap pointers. */
};

/*! \brief A group of statistic mapsets, each set computed on a different surface (e.g. different bone part). */
struct impcore_multi_statmapset_t
{
  unsigned int                  n_statmapsets;  /*!< Number of statmapset pointers. */
  struct impcore_statmapset_t * statmapsets;    /*!< Pointer to start of array of statmapset pointers. */
};


/*! \brief Affine transformation in 3D homogeneous space.

impcore_transform_t is a matrix representation for 3D affine transformations.
Projective transformations are not permitted.

In homogeneous coordinates, a transformation is sometimes
represented by a 4x4 matrix, where the 4th row is always (0,0,0,1)
when projective transformations are forbidden. Therefore, this 
struct represents the transform as a 3 rows x 4 cols matrix, where:
1. The 3x3 submatrix extracted from the first 3 rows and first 3 cols
   encodes anisotropic scaling and rotation.
2. The 4th column encodes translation.

Clients of this struct may choose to restrict the class of transformation
which is permitted for a particular purpose, e.g. Rigid or Similarity.
Responsibility for the validity of the transform lies with the clients:
* creators should impose relevant constraints;
* users should make suitable checks.

The following code snippet illustrates how the transform data is arranged and interpreted.
  Apply a transform T to an input point p to obtain an output point q, such that q = T(p).
  q.x = T[0][0]*p.x + T[0][1]*p.y + T[0][2]*p.z + T[0][3];
  q.y = T[1][0]*p.x + T[1][1]*p.y + T[1][2]*p.z + T[1][3];
  q.z = T[2][0]*p.x + T[2][1]*p.y + T[2][2]*p.z + T[2][3]; */
typedef double impcore_transform_t[3][4];


/*! \brief Voxel type used in IMPCORE images */
typedef float impcore_voxel_t;


/*! \brief A 3D image.

The image is an array of values, to represent a mostly continuous scalar field over R^3 space
sampled on a discrete grid of points.
The image may contain multiple modalities, sampled on the same 3D grid in the same 3D volume,
and thus there will be m scalar values at each spatial grid point (i,j,k).

The value of a voxel (i,j,k,m) represents the value of the underlying image field
for modality m across a region i+-dx, j+-dy, k+-dz where dx,dy,dz is measured in anisotropic
voxels, e.g. dx=0.5.

The following code snippet illustrates how the image data is arranged and interpreted.
  voxel(i,j,k,m) = data[m][k][j][i];
  voxel(i,j,k,m) = *(data + m*nk*nj*ni + k*nj*ni + j*ni + i);

This struct includes a pointer to an external block of memory.
The responsibility for allocating and releasing this memory lies with creators of this struct.

This struct includes a transformation from world/volume (mm) to image (voxel) coordinate frame.
The transformed point is expressed in continuous coordinates.
Clients may wish to interpolate between neighbouring voxel values, or to round to the nearest
integer voxel centre, for example.

\sa impcore_transform_t */
struct impcore_image_t
{
  unsigned int        ni;              /*!< The width of the image in voxels. */
  unsigned int        nj;              /*!< The height of the image in voxels. */
  unsigned int        nk;              /*!< The depth of the image in voxels. */
  unsigned int        nm;              /*!< The number of modalities, i.e. scalar values at each spatial point (i,j,k). */
  const impcore_voxel_t* data;         /*!< Pointer to external image data. That memory is managed by the creator of this struct. */
  impcore_transform_t volume_to_image; /*!< Transform from volume (mm) space to image (voxel) coordinates. */
};

//! \brief patient sex datatype
enum impcore_sex_t
{ 
  impcore_sex_undefined, /*!< Sex has not been specified or is not meaningful */
  impcore_sex_male,      /*!< Sex is male*/
  impcore_sex_female     /*!< Sex is female*/
};

/*! Patient-specific data required as input to unit blocks (impseg, impbscore, impjsw, etc.) */
/*! \note Memory is managed by the client. */
struct impcore_patient_data_t
{
  const char *                case_id;  /*!< Patient name or case identifier */
  enum impcore_side_t         side;     /*!< Patient side */
  struct impcore_image_t      image;    /*!< Image to be segmented */
  enum impcore_sex_t          sex;      /*!< Sex of the patient */
};

/*! \brief Enumeration of specific types permitted in impcore_named_field_t
*/
enum impcore_field_type_t {
  IMPCORE_FIELD_SCALAR,
  IMPCORE_FIELD_BOOL,
  IMPCORE_FIELD_STRING,
  IMPCORE_FIELD_INT32,
  IMPCORE_FIELD_VEC3,
  IMPCORE_FIELD_TRIANGULATION,
  IMPCORE_FIELD_MAT3X4,
  IMPCORE_FIELD_IMAGE,
  IMPCORE_FIELD_CONTOUR,
  IMPCORE_FIELD_TYPE_BEGIN_RANGE = IMPCORE_FIELD_SCALAR,
  IMPCORE_FIELD_TYPE_END_RANGE = IMPCORE_FIELD_CONTOUR,
  IMPCORE_FIELD_TYPE_RANGE_SIZE = (IMPCORE_FIELD_TYPE_END_RANGE - IMPCORE_FIELD_TYPE_BEGIN_RANGE + 1),
  IMPCORE_FIELD_TYPE_MAX_ENUM = 0x7FFFFFFF
};


/*! \brief A key-type-value triplet, with a unique name and where the value can be one of a number of permitted types.
*/
typedef struct impcore_named_field_t
{
  const char* name;                     /*!< A string uniquely identifying this field by name. */
  enum impcore_field_type_t data_type;  /*!< Specifies the type of the value element in an instance of this field. */
  union {
    double scalar;
    struct impcore_point_t point;
    const char* string;
    struct impcore_mesh_t triangulation;
    impcore_transform_t transform;
    bool boolean;
    int integer;
    struct impcore_image_t image;
    struct impcore_contourset_t contour;
  } value;                              /*!< The specific value of this field, which can be one of a number of permitted types. */
} impcore_named_field_t;


/*!
 * \brief The impcore_field_array_t struct describes an array of generic fields.
 *
 * For input parameters, memory is managed by the caller. For outgoing parameters memory is managed
 * by IMPCORE and need to be freed with \c impcore_free_result.
 *
 */
typedef struct impcore_field_array_t
{
  unsigned int n_fields;                /*!< Size of arbitrary/generic field array. */
  struct impcore_named_field_t* fields; /*!< Pointer to start of arbitrary/generic field array. */
} impcore_field_array_t;


/** \brief Log priority enum.
 *
 *  Signifies what level of perceived importance a given log message corresponds to.
 *
 * \note These enum values are originally from SvKitLogPriority_TP from SvKit's types.h and meant to
 *       stay the same to ease integration into the Darlin framework.
 *
 * \note Inside ICLUE, the private mbl_internal_detail::mbl_log_prio_to_impcore converter needs to be
 *       kept in lock-step with this enumeration.
 *
 */
typedef enum impcore_log_priority_t {
  IMPCORE_LOG_PRIORITY_FATAL = 0,        /*!< fatal log message */
  IMPCORE_LOG_PRIORITY_ERROR = 1,        /*!< error log message */
  IMPCORE_LOG_PRIORITY_WARNING = 2,      /*!< warning log message */
  IMPCORE_LOG_PRIORITY_INFORMATION = 3,  /*!< info log message */
  IMPCORE_LOG_PRIORITY_DEBUG = 4,        /*!< debug log message */
  IMPCORE_LOG_PRIORITY_BEGIN_RANGE = IMPCORE_LOG_PRIORITY_FATAL,
  IMPCORE_LOG_PRIORITY_END_RANGE = IMPCORE_LOG_PRIORITY_DEBUG,
  IMPCORE_LOG_PRIORITY_RANGE_SIZE = (IMPCORE_LOG_PRIORITY_END_RANGE - IMPCORE_LOG_PRIORITY_BEGIN_RANGE + 1),
  IMPCORE_LOG_PRIORITY_MAX_ENUM = 0x7FFFFFFF
} impcore_log_priority_t;


/**
 * \brief Callback typedef for IMPCORE function to determine if logging is enabled for given logger
 * category and priority.
 *
 * @param[in] log_category Log category name
 * @param[in] log_priority Log priority of type impcore_log_priority_t
 *
 * \return Returns true if logging category is active for given priority, otherwise false.
 *
 * \remarks The callback will be called from performance sensitive regions, thus it should not
 *          use expensive locking.
 */
typedef bool (*IMPCORE_LOG_CAT_ACTIVE_PROC)(const char* log_category, int log_priority);

/**
 * \brief Callback typedef for IMPCORE log function callback.
 *
 * @param[in] log_category Log category name
 * @param[in] log_time     Timestamp (encoded into string) when log call was issued in IMPCORE.
 * @param[in] log_priority Log priority of type impcore_log_priority_t
 * @param[in] log_msg      Log message.
 *
 */
typedef void (*IMPCORE_LOG_MSG_PROC)(const char* log_category, const char* log_time, int log_priority, const char* log_msg);


/**
 * @brief Structure to pass IMPCORE's log configuration at initialization.
 */
typedef struct impcore_log_config_t
{
  IMPCORE_LOG_CAT_ACTIVE_PROC active_proc; /*!< pointer to callback function \see IMPCORE_LOG_CAT_ACTIVE_PROC */
  IMPCORE_LOG_MSG_PROC msg_proc;           /*!< pointer to callback function \see IMPCORE_LOG_MSG_PROC */
  const char* logger_config_filename;      /*!< String indicating filename of an appropriate IMPCORE logging control file, or null
                                                pointer if default logging verbosity is required. Note that the software is only
                                                validated for default logging. */
} impcore_log_config_t;



//!
//! \brief Parameters for B-score and C-score surface processing
//!
typedef struct impcore_surface_params_t
{
  const unsigned int * interp_nbrhd_topol; /*!< Array of ints defining topological neighbourhood size steps for surface interpolation smoothing.
                                                Recommended config: [16,8,4,2,1] */
  unsigned int n_interp_nbrhd_topol;       /*!< Number of ints in array defining topological neighbourhood size steps for surface interpolation smoothing. */
  double projection_ndt;                   /*!< Surface projection distance threshold. Recommended values: femur/tibia: 5.5, patella: 3.5. */
  unsigned int n_smooths;                  /*!< Number of neighbourhood average smoothing passes to perform on projected
                                                binary image segmentation. Recommended value: 5. */
  unsigned int smooth_nbrhd_size;          /*!< Topological neighbourhood size for neighbourhood average smoothing of projected
                                                binary image segmentation. Recommended value: 1. */
  const char * smooth_nbr_weight;          /*!< Neighbour weighting type for neighbourhood average smoothing of projected binary
                                                image segmentation. Recommended type: nw_equal */
} impcore_surface_params_t;


/************************************************
* Items defined by the client
************************************************/

/*! \brief A processing function/object, passed by pointer from calling code to impcore computation functions and back to client progress function. */
/*! \note The memory is managed by the client. */
struct impcore_progress_context_t;

/*! \brief Callback function to be defined by the client and called by IMPCORE computational functions.*/
/*! \param double indicates estimated progress of entire operation from 0.0 to 1.0. */
/*! \param impcore_progress_context_t May be null, or a pointer to a function/object on the client's side providing information about the calling context, if specified to the computational function.*/
/*! \return Non-zero if the client wants to cancel the operation, or zero otherwise. */
typedef int (*impcore_progress_fptr_t)(double, struct impcore_progress_context_t*);


#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* IMPCORE__ */