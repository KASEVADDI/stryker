#pragma once

/******************************************************************************
*
* Copyright  2015 Imorphics, All Rights Reserved
*
* FILENAME:    impseg.h
*
* DESCRIPTION: Contains the functions of the IMPSEG software.
*              All the types and functions used in this file have to be
*              compilable as "C" code, and the functions have to be defined
*              with extern "C" linkage, according to the ABI for the
*              given platform. This file contains the main description of the API.
*
*              This header will be shared outside Imorphics to define
*              the interface (API) to the Imorphics IMPSEG library.
*
******************************************************************************/


#include <impcore/impcore.h>


#ifdef __cplusplus
extern "C" {
#endif


/*! Unique, monotonically increasing version number of the IMPSEG API. */
/*! \note This number is not the same as the binary library version, which is obtained using impseg_get_version(). */
/*! \note This version will change when either this file or impcore.h change. */
#define IMPSEG_API_VERSION 28


/************************************************
* Data types
************************************************/

/*! The result of an image segmentation. */
/*! \note Memory is managed by IMPSEG. */
struct impseg_result_t
{
  struct impcore_meshset_t meshset;
};

/*! An image segmentation model. */
/*! \note Memory is managed by IMPSEG. */
/*! \note This is an opaque type, declared here but not defined in the API. */
struct impseg_model_t;

/*! Information about an image segmentation model. */
/*! \note Memory is managed by IMPSEG. */
struct impseg_model_info_t
{
  const char *               name;                /*!< Model name or identifier. */
  enum impcore_side_t        side;                /*!< Model side. */
  const char *               modality;            /*!< Model imaging modality. */
  struct impcore_meshset_t   parts;               /*!< A set of canonical model parts, e.g. the mean model surfaces. These surfaces are in an arbitrary reference frame and have no relation to any image. */
  unsigned int               n_training_data_ids; /*!< Deprecated. Always 0. */
  const char **              training_data_ids;   /*!< Deprecated. Always null. */
  enum impcore_gpu_enabled_t  gpu_enabled;         /*!< Whether the model uses a GPU */
};


/************************************************
* Functions
************************************************/

/*! \brief Initialize this library. To be called exactly once by the client, in a single-threaded context, before any other IMPSEG functions. */
/*! \param logger_config_filename String indicating filename of an appropriate IMPSEG logging control file, or null pointer if default logging is required. */
/*! \return Whether the IMPSEG library was successfully initialized. If rv!=impcore_rv_success, do not call any other IMPSEG functions. */
IMPCORE_API_CALL enum impcore_rv impseg_initialize(
  const char * logger_config_filename);
  
/*! \brief Get a string indicating the current library version. */
/*! \retval version A pointer to a string indicating the current library version. The client should pass in a null pointer-to-const-char* which will be set by this function to point to a string internal to this library. The client should not attempt to modify or delete this string. */
IMPCORE_API_CALL enum impcore_rv impseg_get_version(
  const char ** version);

/*! \brief Load an image segmentation model. This function allocates the required memory for the model. The client must call impseg_free_model() when the model is no longer required. */
/*! \param filename String indicating filename of an appropriate image segmentation model. */
/*! \retval model The loaded model which can be passed to impseg_segment_image(). \a model remains in memory until a call to impseg_free_model(). */
/*! \return Whether the model was successfully loaded. If rv!=impcore_rv_success, do not use any output params, and do not call impseg_segment_image() or impseg_free_model(). */
IMPCORE_API_CALL enum impcore_rv impseg_load_model(
  const char * filename,
  struct impseg_model_t ** model);

/*! \brief Get information about an image segmentation model. */
/*! \param model Pointer to a loaded image segmentation model. */
/*! \retval info Pointer to struct which will be allocated by this function and filled with model information. \a info remains in memory until a call to impseg_free_model_info(). */
/*! \return Whether the model information was successfully obtained. If rv!=impcore_rv_success, do not use any output params. */
IMPCORE_API_CALL enum impcore_rv impseg_get_model_info(
  const struct impseg_model_t * model,
  struct impseg_model_info_t ** info);

/*! \brief Get information about an user's hardware (graphics card). */
/*! \retval hdwr Pointer to an enum from the impcore_user_hardware_t */
/*! \return Whether the hdwr was successfully obtained. If rv!=impcore_rv_success, do not use any output params. */
IMPCORE_API_CALL enum impcore_rv impseg_get_user_hardware_info(
  enum impcore_user_hardware_t * hdwr);

/*! \brief Segment an image. This function allocates the required memory for the returned data. The client must call impseg_free_result() when this data is no longer in use. */
/*! After a call to impseg_segment_image() has completed, the client is free to delete \a patient_data. */
/*! \param model An appropriate image segmentation model, loaded with impseg_load_model(). */
/*! \param patient_data Patient data for image segmentation. patient_data.sex is not used by this method. NB This function is permitted to modify the data. */
/*! \param max_compute_threads The maximum number of computationally-intensive threads which impseg_segment_image may run at one time. The value 0 indicates that the implementation can decide. */
/*! \param per_case_processing_object Client-defined object used to identify the calling context. Will be passed back in progress callback. */
/*! \param progress Client-defined callback function which will be called by this function to indicate progress. */
/*! \retval result The result of the image segmentation. This object stays in memory until a call to impseg_free_result(). */
/*! \return Whether the operation successfully completed. If rv!=impcore_rv_success, do not use any output params, and do not call impseg_free_result(). */
IMPCORE_API_CALL enum impcore_rv impseg_segment_image(
  const struct impseg_model_t * model,
  struct impcore_patient_data_t * patient_data,
  unsigned int max_compute_threads,
  struct impcore_progress_context_t* per_case_processing_object,
  impcore_progress_fptr_t progress,
  struct impseg_result_t ** result);

/*! \brief Free the memory used to hold the result from one call to impseg_segment_image(). The client must ensure that this data is no longer in use. */
/*! \param result The result of a previous call to impseg_segment_image(). The pointer should not be used again. */
/*! \return At present, no error-checking is performed and the return value is always impcore_rv_success. */
IMPCORE_API_CALL enum impcore_rv impseg_free_result(
  struct impseg_result_t * result);

/*! \brief Free the memory used to store information from one call to impseg_get_model_info(). The client must ensure that this data is no longer in use. */
/*! \param info The result of a previous call to impseg_get_model_info(). The pointer should not be used again. */
/*! \return At present, no error-checking is performed and the return value is always impcore_rv_success. */
IMPCORE_API_CALL enum impcore_rv impseg_free_model_info(
  struct impseg_model_info_t * info);

/*! \brief Free the memory used to hold an image segmentation model. The client must ensure that this model is no longer in use. */
/*! \param model An image segmentation model, loaded with impseg_load_model(). The pointer should not be used again. */
/*! \note Do not call this function whilst any impseg_model_info_t or impseg_result_t obtained using this model are still in use. */
/*! \return At present, no error-checking is performed and the return value is always impcore_rv_success. */
IMPCORE_API_CALL enum impcore_rv impseg_free_model(
  struct impseg_model_t * model);

/*! \brief End use of the IMPSEG library. To be called exactly once by the client, in a single-threaded context, after all other IMPSEG functions. */
/*! \note Do not call this function while any IMPSEG objects still exist (e.g. impseg_model_t, impseg_result_t). */
/*! \return At present, no error-checking is performed and the return value is always impcore_rv_success. */
IMPCORE_API_CALL enum impcore_rv impseg_finalize();


#ifdef __cplusplus
} /* extern "C" */
#endif


