#**********************************************************************#
#
#   Copyright (c)
#   Stryker Leibinger GmbH & Co.KG,
#   Boetzinger Strasse 41,
#   79111 Freiburg / Germany
#
#
#   File:        impsegConfig.cmake
#
#   Description: importable target for impseg lib
#
#
#***********************************************************************#

set (_TARGET impseg)
if (TARGET ${_TARGET})
    message (STATUS "Target ${_TARGET} was already included")
else()
    add_library (${_TARGET} SHARED IMPORTED)
    set (_IMPORT_PREFIX "${CMAKE_CURRENT_LIST_DIR}")
    get_filename_component(_IMPORT_PREFIX "${_IMPORT_PREFIX}" PATH)
    if(WIN32)
    set_target_properties (${_TARGET} PROPERTIES
        VERSION "38.0.2"
        IMPORTED_CONFIGURATIONS "Debug;Release"
        INTERFACE_INCLUDE_DIRECTORIES "${_IMPORT_PREFIX}/include"
        IMPORTED_IMPLIB_DEBUG "${_IMPORT_PREFIX}/lib/impsegd.lib"
        IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/impseg.lib"
        IMPORTED_LOCATION_DEBUG "${_IMPORT_PREFIX}/bin/impsegd.dll"
        IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/impseg.dll"
    )
    # mark DLLs for copy
    set_property (GLOBAL APPEND PROPERTY SYK_COPY_FILES "${_IMPORT_PREFIX}/bin/impsegd.dll=>${CMAKE_RUNTIME_OUTPUT_DIRECTORY_DEBUG}")
    set_property (GLOBAL APPEND PROPERTY SYK_COPY_FILES "${_IMPORT_PREFIX}/bin/impseg.dll=>${CMAKE_RUNTIME_OUTPUT_DIRECTORY_RELEASE}")
    endif(WIN32)
    if(UNIX)
      set_target_properties (${_TARGET} PROPERTIES
        VERSION "38.0.2"
        IMPORTED_CONFIGURATIONS "Debug;Release"
        INTERFACE_INCLUDE_DIRECTORIES "${_IMPORT_PREFIX}/include"
        IMPORTED_IMPLIB_DEBUG "${_IMPORT_PREFIX}/lib/libimpsegd.so"
        IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libimpseg.so"
        IMPORTED_LOCATION_DEBUG "${_IMPORT_PREFIX}/lib/libimpsegd.so"
        IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libimpseg.so"
      )
    endif(UNIX)
endif()
set (impseg 1)
unset (_TARGET)
